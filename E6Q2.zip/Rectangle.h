#pragma once
#include "Polygon.h"
class Rectangle :public Polygon
{
public:
	Rectangle(int side1, int side2);   //constructor
	~Rectangle();
};